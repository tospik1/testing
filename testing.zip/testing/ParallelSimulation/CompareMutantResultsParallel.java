import java.io.*;
import java.util.*;

public class CompareMutantResultsParallel{
		
		public static void main(String[] args) throws Exception{
			int testNumber= Integer.parseInt(args[0]);
			
			String originalResult,a,b;
			String[] elements= new String[2];
			
			Scanner sc = new Scanner(new FileInputStream("TestCases.txt"));
			Scanner sc2= new Scanner(new FileInputStream("./Results/OriginalResults.txt"));
			
			for(int i=0; i<testNumber-1;i++){
				sc.nextLine();
				sc2.nextLine();
			}
			
			originalResult=sc2.nextLine(); originalResult=originalResult.trim();
			elements=sc.nextLine().split(" ");
			a=elements[0]; b=elements[1];
			
			Threading1 thread1=new Threading1(a,b);
			Threading2 thread2=new Threading2(a,b);
			Threading3 thread3=new Threading3(a,b);
			
			thread1.start(); //3 different threads for 3 different mutants
			thread2.start();
			thread3.start();
			thread1.join(5000);thread2.join(5000);thread3.join(5000);
			
			
			int coda=1;
			
			if(!originalResult.equals(thread1.mutantResult.trim()))coda=coda*2;//the proocess exit value will be acode for which test(s) was killed
			
			if(!originalResult.equals(thread2.mutantResult.trim()))coda=coda*3;
			
			if(!originalResult.equals(thread3.mutantResult.trim()))coda=coda*5;
			
			if(coda!=1)System.exit(coda);
			
			System.exit(0);
			
			
		}

}

class Threading1 extends Thread{
		String mutantResult,a,b;
		Mutant1 mutant;
		Threading1(String a2, String b2){
			a=a2;b=b2;
			mutant=new Mutant1();
			mutantResult="";
		}
		
		
		public void run(){
					try{
						mutantResult=mutant.getDivisors(a)+mutant.getDivisors(b)+mutant.getPrimeFactors(a)+mutant.getPrimeFactors(b)+mutant.getGCD(a,b)+ mutant.getLCM(a,b);
					}
					catch(Exception e1){
						mutantResult="fail";
					}
		}

}

class Threading2 extends Thread{
		String mutantResult,a,b;
		Mutant2 mutant;
		Threading2(String a2, String b2){
			a=a2;b=b2;
			mutant=new Mutant2();
			mutantResult="";
		}
		
		
		public void run(){
					try{
						mutantResult=mutant.getDivisors(a)+mutant.getDivisors(b)+mutant.getPrimeFactors(a)+mutant.getPrimeFactors(b)+mutant.getGCD(a,b)+ mutant.getLCM(a,b);
					}
					catch(Exception e1){
						mutantResult="fail";
					}
		}

}

class Threading3 extends Thread{
		String mutantResult,a,b;
		Mutant3 mutant;
		Threading3(String a2, String b2){
			a=a2;b=b2;
			mutant=new Mutant3();
			mutantResult="";
		}
		
		
		public void run(){
					try{
						mutantResult=mutant.getDivisors(a)+mutant.getDivisors(b)+mutant.getPrimeFactors(a)+mutant.getPrimeFactors(b)+mutant.getGCD(a,b)+ mutant.getLCM(a,b);
					}
					catch(Exception e1){
						mutantResult="fail";
					}
		}

}

