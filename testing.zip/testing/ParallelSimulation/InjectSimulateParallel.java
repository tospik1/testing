import java.util.*;
import java.io.*;

public class InjectSimulateParallel{

	static ArrayList<Integer> lineNumbers;
	static ArrayList<Integer> positionInLine;
	static ArrayList<Character> theCharacter;
	static int sizeList;
	static ArrayList<String> testCases;
	static int sizeTestCases;
	static int mutantsKilled;
	static PrintWriter conclusion;
	static String[] names;
	
	
	public static void main(String[] args) throws Exception{
		long startTime= System.currentTimeMillis();
		
		names= new String[3];
		readList(); //read mutant library
		readTestCases(); //read test cases
		
		mutantsKilled=0;
		String mutantName;
		conclusion= new PrintWriter("./Results/ConclusionParallel.txt");
		
		boolean[] killed= new boolean[3];
		int[] killer= new int[3];
		for(int listIterator=0; listIterator<sizeList; listIterator++){ //go through the mutant library
			char originalChar= theCharacter.get(listIterator);
			int lineNumber= lineNumbers.get(listIterator);
			int position= positionInLine.get(listIterator);
			for(int r=0; r<3;r++){
				killed[r]=false; killer[r]=-1;
			}
			
			createMutantFiles(lineNumber, position, originalChar); //create the 3 different mutants for this location
			if(runProcess("javac -sourcepath ParallelSimulation -d ParallelSimulation ParallelSimulation/Mutant*.java ParallelSimulation/CompareMutantResultsParallel.java")!=0){
				System.out.println("Something wrong");
				
			}
			else{
				int caseIterator= 1;
				int ret;
				
				while(caseIterator<=sizeTestCases && (  (!killed[0])  || (!killed[1]) || (!killed[2])  )){ //run test cases until all 3 mutants killed
					ret= runProcess("java -cp ParallelSimulation  CompareMutantResultsParallel "+String.valueOf(caseIterator));
					
					if(ret==0){caseIterator++;continue;}
					if(ret%2==0 && !killed[0]){ killed[0]=true; killer[0]=caseIterator;mutantsKilled++;}
					if(ret%3==0 && !killed[1]){ killed[1]=true; killer[1]=caseIterator;mutantsKilled++;}
					if(ret%5==0 && !killed[2]){ killed[2]=true; killer[2]=caseIterator;mutantsKilled++;}
					
					caseIterator++;
					
								
				}

				String output="";
				for(int r=0;r<3;r++){
					if(killed[r]){ // output: which mutant was killed by which test case
						output=output+names[r]+ " was killed by test case"+ String.valueOf(killer[r])+ "\n";
					}
					else{
						output=output+names[r]+ " was not killed by any test case\n";
					}
				}
				conclusion.print(output);
				
			}
				
				
		}
		
		
		double ratio = ((double) (mutantsKilled))/ (3.0 * ((double) sizeList));
		conclusion.print("Mutant coverage ratio is: "+ String.valueOf(ratio)+"\n");
		long durationB=(-startTime+System.currentTimeMillis())/1000;
		conclusion.print("The parallel simulation took "+ durationB +" seconds.");
		conclusion.close();
		
	
	}
	
	public static void readList() throws Exception{//read mutant library
		Scanner sc = new Scanner(new FileInputStream("./Results/MutantLibrary.txt"));
		String line;
		sizeList=0;
		String[] elements= new String[3];
		lineNumbers= new ArrayList<Integer>();
		positionInLine= new ArrayList<Integer>();
		theCharacter= new ArrayList<Character>();
		while(sc.hasNextLine()){
			line=sc.nextLine().trim();
			if(line.length()>0){
				sizeList++;
				elements=line.split(" ");
				lineNumbers.add(Integer.parseInt(elements[0]));
				positionInLine.add(Integer.parseInt(elements[1]));
				theCharacter.add(elements[2].charAt(0));
			}
			
		}
		sc.close();
		
		
		
	}
	
	
	
	public static void readTestCases() throws Exception{ //read test cases
		Scanner sc = new Scanner(new FileInputStream("TestCases.txt"));
		String line;
		sizeTestCases=0;
		testCases= new ArrayList<String>();
		while(sc.hasNextLine()){
			line=sc.nextLine().trim();
			if(line.length()>0){
				sizeTestCases++;
				testCases.add(line);
			}
		}
		sc.close();
	}
	
	
	
	
	
	private static int runProcess(String command) throws Exception { //run a subprocess
        Process pro = Runtime.getRuntime().exec(command);
        
		pro.waitFor();
		return pro.exitValue();
     }
	 
	 
	 public static void createMutantFiles(int lineNumber, int pos, char ori) throws Exception{ //create the 3 mutant files
		 String mutantName = "Mutant_Line"+ String.valueOf(lineNumber) + "_Pos"+ String.valueOf(pos)+ "_";
		 char mut1,mut2,mut3;mut1='q';mut2='q';mut3='q';
		 if(ori=='+'){//determining the assignment of the mutants to each char and their names
			 mut1='-';names[0]=mutantName+"minus";
			 mut2='*';names[1]=mutantName+"times";
			 mut3='/';names[2]=mutantName+"divided";
		 }
		 else if(ori=='-'){
			 mut1='+';names[0]=mutantName+"plus";
			 mut2='*';names[1]=mutantName+"times";
			 mut3='/';names[2]=mutantName+"divided";
		 }
		 else if(ori=='*'){
			mut1='+';names[0]=mutantName+"plus";
			 mut2='-';names[1]=mutantName+"minus";
			 mut3='/';names[2]=mutantName+"divided";
		 }
		 else if(ori=='/'){
			mut1='+';names[0]=mutantName+"plus";
			 mut2='-';names[1]=mutantName+"minus";
			 mut3='*';names[2]=mutantName+"times";
		 }
		 
		 
		 
		 Scanner reader= new Scanner(new FileInputStream("./SUT/ProjectBackend.java"));
		 PrintWriter writer1 = new PrintWriter ("./ParallelSimulation/Mutant1.java");
		 PrintWriter writer2 = new PrintWriter ("./ParallelSimulation/Mutant2.java");
		 PrintWriter writer3 = new PrintWriter ("./ParallelSimulation/Mutant3.java");
		 
		 writer1.print("import static java.lang.Math.abs;\n\npublic class Mutant1{\n\n");
		 writer2.print("import static java.lang.Math.abs;\n\npublic class Mutant2{\n\n");
		 writer3.print("import static java.lang.Math.abs;\n\npublic class Mutant3{\n\n"); //hardcoded to ensure Mutant?.java name
		 reader.nextLine();reader.nextLine();reader.nextLine();reader.nextLine();
		 int i=5;
		 String dummy;
		 while(reader.hasNextLine()){
			 if(i==lineNumber){
				 dummy= reader.nextLine();
				 if(pos==dummy.length()-1){
					 writer1.print(dummy.substring(0,pos));writer2.print(dummy.substring(0,pos));writer3.print(dummy.substring(0,pos));
					 writer1.println(mut1);writer2.println(mut2);writer3.println(mut3);
					 
				 }
				 else{
					 String dummy2 = dummy.substring(pos+1);
					 writer1.println(dummy.substring(0,pos)+Character.toString(mut1) + dummy2);
					 writer2.println(dummy.substring(0,pos)+Character.toString(mut2) + dummy2);
					 writer3.println(dummy.substring(0,pos)+Character.toString(mut3) + dummy2);
				 }
			 }
			 else{
				 dummy= reader.nextLine();
				 writer1.print(dummy+"\n");writer2.print(dummy+"\n");writer3.print(dummy+"\n");
			 }
			 
			 i++;
		 }
		 reader.close();
		 writer1.close();writer2.close();writer3.close();
	 }

}