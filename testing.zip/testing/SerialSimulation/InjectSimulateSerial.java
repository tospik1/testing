import java.util.*;
import java.io.*;

public class InjectSimulateSerial{

	static ArrayList<Integer> lineNumbers;
	static ArrayList<Integer> positionInLine;
	static ArrayList<Character> theCharacter;
	static int sizeList;
	static ArrayList<String> testCases;
	static int sizeTestCases;
	static int mutantsKilled;
	static PrintWriter conclusion;
	
	
	public static void main(String[] args) throws Exception{
		long startTime=System.currentTimeMillis();
		
		char[] operations={'+','-','*','/'};
		String[] equivalent={"plus","minus","times","divided"};
		
		
		readList(); //read the mutant library
		readTestCases(); //read the test cases
		
		mutantsKilled=0;
		String mutantName;
		conclusion= new PrintWriter("./Results/ConclusionSerial.txt");
		for(int listIterator=0; listIterator<sizeList; listIterator++){ //go through each injection site
			char originalChar= theCharacter.get(listIterator);
			int lineNumber= lineNumbers.get(listIterator);
			int position= positionInLine.get(listIterator);
			
			for(int operationIterator=0;operationIterator<4; operationIterator++){ //inject with one of the different 3other operators
				char mutantChar= operations[operationIterator];
				
				if(mutantChar != originalChar){
						mutantName = "Mutant_Line"+ String.valueOf(lineNumber) + "_Pos"+ String.valueOf(position)+ "_"+ equivalent[operationIterator];
						createMutantFile(lineNumber, position, mutantChar); //create Mutant.java with the specified mutation
						
						//compile the driver for the mutant
						if(runProcess("javac -sourcepath SerialSimulation -d SerialSimulation SerialSimulation/Mutant.java SerialSimulation/CompareMutantResultsSerial.java")==false){
							mutantsKilled++;
							conclusion.print(mutantName+ " was killed during compilation\n");
						}
						else{
							boolean success=true;
							int caseIterator= 1;
							while(caseIterator<=sizeTestCases && success){ //run until test cases finished or until mutant killed (whatever earliest)
								//run the driver of the mutant
								success= runProcess("java -cp SerialSimulation  CompareMutantResultsSerial "+String.valueOf(caseIterator));
								if(success==false){
									mutantsKilled++;
									conclusion.print(mutantName+ " was killed by test case"+ String.valueOf(caseIterator)+ "\n");
									break;
								}
								caseIterator++;
								
							} 
							if(success==true)conclusion.print(mutantName+ " was not killed by any test case\n");
						}
				}
			}	
		}
		
		
		double ratio = ((double) (mutantsKilled))/ (3.0 * ((double) sizeList));
		conclusion.println("Mutant coverage ratio is: "+ String.valueOf(ratio));
		long durationA=(-startTime+System.currentTimeMillis())/1000;
		conclusion.print("The serial simulation took "+durationA+" seconds.");
		conclusion.close();
		
	
	}
	
	public static void readList() throws Exception{ //read mutant library
		Scanner sc = new Scanner(new FileInputStream("./Results/MutantLibrary.txt"));
		String line;
		sizeList=0;
		String[] elements= new String[3];
		lineNumbers= new ArrayList<Integer>();
		positionInLine= new ArrayList<Integer>();
		theCharacter= new ArrayList<Character>();
		while(sc.hasNextLine()){
			line=sc.nextLine().trim();
			if(line.length()>0){
				sizeList++;
				elements=line.split(" ");
				lineNumbers.add(Integer.parseInt(elements[0]));
				positionInLine.add(Integer.parseInt(elements[1]));
				theCharacter.add(elements[2].charAt(0));
			}
			
		}
		sc.close();
		
		
		
	}
	
	
	
	public static void readTestCases() throws Exception{ //read test cases
		Scanner sc = new Scanner(new FileInputStream("TestCases.txt"));
		String line;
		sizeTestCases=0;
		testCases= new ArrayList<String>();
		while(sc.hasNextLine()){
			line=sc.nextLine().trim();
			if(line.length()>0){
				sizeTestCases++;
				testCases.add(line);
			}
		}
		sc.close();
	}
	
	
	
	
	
	private static boolean runProcess(String command) throws Exception { //run a CLI command
        Process pro = Runtime.getRuntime().exec(command);
        /*if(pro.waitFor(10, TimeUnit.SECONDS)==false){
			pro.destroyForcibly();
			return false;
		}*/
		pro.waitFor();
        if(pro.exitValue() !=0) return false;//if process ended with an error
		return true;
     }
	 
	 
	 public static void createMutantFile(int lineNumber, int pos, char mut) throws Exception{
		 Scanner reader= new Scanner(new FileInputStream("./SUT/ProjectBackend.java"));
		 PrintWriter writer = new PrintWriter ("./SerialSimulation/Mutant.java");
		 
		 writer.print("import static java.lang.Math.abs;\n\npublic class Mutant{\n\n");// harcoded to allow the renaming to Mutant.java
		 reader.nextLine();reader.nextLine();reader.nextLine();reader.nextLine();
		 int i=5;
		 while(reader.hasNextLine()){
			 if(i==lineNumber){ //the line containing the mutation
				 String dummy= reader.nextLine();
				 if(pos==dummy.length()-1){//character at the end of the line
					 writer.print(dummy.substring(0,pos));
					 writer.print(mut);
					 writer.println();
				 }
				 else{ //copy the line except the character (replaced by the mutant char)
					 String dummy2 = dummy.substring(pos+1);
					 writer.println(dummy.substring(0,pos)+Character.toString(mut) + dummy2);
				 }
			 }
			 else{
				 writer.print(reader.nextLine()+"\n");
			 }
			 
			 i++;
		 }
		 reader.close();
		 writer.close();
	 }

}