import java.io.*;
import java.util.*;

public class CompareMutantResultsSerial{
		
		public static void main(String[] args) throws Exception{
			int testNumber= Integer.parseInt(args[0]);
			
			String originalResult,a,b;
			String[] elements= new String[2];
			
			Scanner sc = new Scanner(new FileInputStream("TestCases.txt"));
			Scanner sc2= new Scanner(new FileInputStream("./Results/OriginalResults.txt"));
			
			for(int i=0; i<testNumber-1;i++){
				sc.nextLine();
				sc2.nextLine();
			}
			
			originalResult=sc2.nextLine(); originalResult=originalResult.trim();
			elements=sc.nextLine().split(" ");
			a=elements[0]; b=elements[1];
			
			Threading thread=new Threading(a,b);
			
			thread.start(); //run the methods in the mutant in a parallel thread
			thread.join(5000);
			
			String res=thread.mutantResult.trim();
			if(!originalResult.equals(res))System.exit(1);
			System.exit(0);
			
			
		}

}

class Threading extends Thread{
		String mutantResult,a,b;
		Mutant mutant;
		Threading(String a2, String b2){
			a=a2;b=b2;
			mutant=new Mutant();
			mutantResult="";
		}
		
		
		public void run(){
					try{
						mutantResult=mutant.getDivisors(a)+mutant.getDivisors(b)+mutant.getPrimeFactors(a)+mutant.getPrimeFactors(b)+mutant.getGCD(a,b)+ mutant.getLCM(a,b);
					}
					catch(Exception e1){
						mutantResult="fail";
					}
		}

}