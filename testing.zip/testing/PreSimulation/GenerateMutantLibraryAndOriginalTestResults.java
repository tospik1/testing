
//java file
import java.io.*;
import java.util.*;

public class GenerateMutantLibraryAndOriginalTestResults{
		public static void main(String[] args)throws Exception{
				Scanner sc = new Scanner(new FileInputStream(args[0])); //open a reader for the file passed as argument
				PrintWriter hh= new PrintWriter("./Results/MutantLibrary.txt"); // the file where we will store the library
				String line;
				int lineCounter=0;
				char dummy;
				while(sc.hasNextLine()){ // while there are liness of code
						lineCounter++;
						line=sc.nextLine(); // get an individual line
						for(int i=0; i<line.length();i++){ // go through individual lines
							dummy= line.charAt(i);
							if(dummy=='+'){
									
									hh.print(lineCounter + " "+ i + " " + "+" +"\n"); //for each mutant print a new line
																						// lineNumber charPositionInThisLine originalSign
							}
							else if(dummy=='-'){
									
									hh.print(lineCounter + " "+ i + " " + "-"+"\n");
							}
							else if(dummy=='*'){
									
									hh.print(lineCounter + " "+ i + " " + "*"+"\n");
							}
							else if(dummy=='/'){
									if(i<line.length()-1){
										if(line.charAt(i+1)=='/')break;    //encounter a java comment
									}
									
									hh.print(lineCounter + " "+ i + " " + "/"+"\n");
							}
						}
					
				}
				sc.close();
				hh.close();
				
				ArrayList<String> testCases= new ArrayList<String>();
		
				sc= new Scanner(new FileInputStream("TestCases.txt")); //read the different test cases
				
				int sizeTestCases=0;
				while(sc.hasNextLine()){
					line=sc.nextLine().trim();
					if(line.length()>0){
						sizeTestCases++;
						testCases.add(line);
					}
				}
				sc.close();
		
				ProjectBackend backend= new ProjectBackend();
		
				String a,b,result;
				String[] elements= new String[2];
		
				hh= new PrintWriter("./Results/OriginalResults.txt");
	
		
				for(int i=0; i<sizeTestCases; i++){ //call the 4 SUT methods on each test case and store the result in ./Results/OriginalResults.txt
					elements=testCases.get(i).split(" ");
					a=elements[0];b=elements[1];
					result=backend.getDivisors(a)+backend.getDivisors(b)+backend.getPrimeFactors(a)+backend.getPrimeFactors(b)+backend.getGCD(a,b)+ backend.getLCM(a,b)+"\n";
					hh.print(result);
			
				}
		
				hh.close();
				
				
				
				
				
		}

}