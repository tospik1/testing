import static java.lang.Math.abs;

public class ProjectBackend{
 
	public String getDivisors(String number){ //get a list of divisors for an integer
		//error handling
		if(number==null) return "Please enter an integer number in the input";
		number=number.trim();
		if (number.isEmpty())return "Please enter an integer number in the input";
		int n=0;
		try{
			n=Integer.parseInt(number);
		}
		catch(NumberFormatException e){
			return "Please enter an integer number in the input";
		}
  
		n=abs(n);
		if(n==0) return "Any integer number is a divisor of zero"; //trivial cases
		if(n==1) return "[ 1 ]";
		if(n==2) return "[ 1, 2 ]";
		String output= "[ 1";
		for(int i=2;i< n;i=i+1){ //check if i divides n
			if(n%i==0){
				output=output.concat(", ");
				output=output.concat(String.valueOf(i));
			}
		}
		output=output.concat(", ");
		output=output.concat(String.valueOf(n));
		output=output.concat(" ]");
		return output;
	}
 
	public String getPrimeFactors(String number){ //get the list of prime facotors for a number
		if(number==null) return "Please enter an integer number in the input"; //error handling
		number=number.trim();
		if (number.isEmpty())return "Please enter an integer number in the input";
		int n=0;
		try{
			n=Integer.parseInt(number);
		}
		catch(NumberFormatException e){
			return "Please enter an integer number in the input";
		}
  
		n=abs(n);
		if(n==0) return "Any prime number is a factor of zero"; //trivial cases
		if(n==1) return "1 does not have prime factorization";
		if(n==2) return "[ 2 ]";
		String output= "[ ";
		for(int i=2; i< n ; i=i+1){
			while(n%i==0 && n>=i){ //divide n by an ascending i as much as possible
				output=output.concat(String.valueOf(i));
				output=output.concat(", ");
				n=n/i;   //a simple comment
			}
		}
  
  
		if(n>2){ //if still a prime factor remaining
			output=output.concat(String.valueOf(n));
			output=output.concat(", ");
		}
  
		int length=output.length();
		output=output.substring(0,length-2);
		output=output.concat(" ]");
		return output;
  
	}
 
 
	public String getGCD(String number1, String number2){ //get gcd of 2 numbers
		if(number1==null || number2==null) return "Please enter integer numbers in both inputs";
		number1=number1.trim();number2=number2.trim();
		int n1=0;int n2=0;
		try{
			n1=Integer.parseInt(number1);
			n2=Integer.parseInt(number2);
		}
		catch(NumberFormatException e){
			return "Please enter integer numbers in both inputs";
		}
  
		n1=abs(n1); n2=abs(n2);
		int max=n1; int min=n2;
		if(min>max){
			min=n1;
			max=n2;
		}
  
		if(min==0)return String.valueOf(max); //trivial cases
		if(min==1)return "1";
		if(max%min==0)return String.valueOf(min);
  
		int r; //euclid algorithm
		while(min !=0){
			r=max%min;
			max=min;
			min=r;
		}
		return String.valueOf(max);
  
	}
 
 
	public String getLCM (String number1, String number2){// get least common multiple of 2 numbers
		if(number1==null || number2==null) return "Please enter integer numbers in both inputs"; //error handling
		number1=number1.trim();number2=number2.trim();
		int n1=0;int n2=0;
		try{
			n1=Integer.parseInt(number1);
			n2=Integer.parseInt(number2);
		}
		catch(NumberFormatException e){
			return "Please enter integer numbers in both inputs";
		}
  
		n1=abs(n1); n2=abs(n2);
		int max=n1; int min=n2;
		if(min>max){
			min=n1;
			max=n2;
		}
  
		if(min==0)return "0"; //trivial cases
		if(max%min==0)return String.valueOf(max);
  
		return String.valueOf(     max*min/Integer.parseInt(  getGCD(number1,number2) )     ); //use formula cm= a*b/gcd(a,b)
  
	}
 
 
 

}