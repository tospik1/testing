import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class MainDriver{


	public static void main(String[] args){
		
		JFrame frame = new JFrame("Our Simple software");
		frame.setLayout(new GridLayout(0,1));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		ProjectBackend backend= new ProjectBackend();
		
		JLabel inputLabelA = new JLabel("Integer A (Enter value in the box below) :");
		JLabel inputLabelB = new JLabel("Integer B (Enter value in the box below) :");
		JLabel outputdA = new JLabel("List of divisors of Integer A: Please enter an integer number in the input");
		JLabel outputdB = new JLabel("List of divisors of Integer B: Please enter an integer number in the input");
		JLabel outputpA = new JLabel("Prime factorization of Integer A: Please enter an integer number in the input");
		JLabel outputpB = new JLabel("Prime factorization of Integer B: Please enter an integer number in the input");
		JLabel gcd =  new JLabel("GCD of integers A and B: Please enter integer numbers in both inputs");
		JLabel lcm = new JLabel("LCM of integers A and B: Please enter integer numbers in both inputs");
		
		
		TextField a= new TextField("");
		TextField b= new TextField("");
		
		
		
		JButton update= new JButton("Update"); //pressing on the Update Button calls the backend methods and displays the results
		update.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				
				
				outputdA.setText("List of divisors of Integer A: "+ backend.getDivisors(a.getText()));
				outputdB.setText("List of divisors of Integer B: "+ backend.getDivisors(b.getText()));
				outputpA.setText("Prime factorization of Integer A: "+backend.getPrimeFactors(a.getText()));
				outputpB.setText("Prime factorization of Integer B: "+backend.getPrimeFactors(b.getText()));
				gcd.setText("GCD of integers A and B: "+backend.getGCD(a.getText(),b.getText()));
				lcm.setText("LCM of integers A and B: "+backend.getLCM(a.getText(),b.getText()));
				
				
				
			}  
		});
		
		frame.add(inputLabelA);
		frame.add(a);
		frame.add(inputLabelB);
		frame.add(b);
		frame.add(outputdA);
		frame.add(outputdB);
		frame.add(outputpA);
		frame.add(outputpB);
		frame.add(gcd);
		frame.add(lcm);
		frame.add(update);
		
		frame.setSize(800,600);
		
		
		frame.setVisible(true);
		
	}


}